import pygame
import json
import threading
import time

#----------------------상수 정의역-----------------------#
SCREEN_WIDTH = 600 # 가로
SCREEN_HEIGHT = 800 # 세로

RECORD_SCALE = 390 # 음반 사진 스케일

INTRO_BACKGROUND_PATH = "./resources/intro_background.jpg"
INTRO_START_PATH = "./resources/intro_start.png"
ARROW_PATH = "./resources/arrow.png"
PLAY_PATH = "./resources/play.png"
BACK_PATH = "./resources/back.png"
SELECT_ARROW_PATH = "./resources/select_arrow.png"
GALMURI_FONT_PATH = "./resources/fonts/Galmuri11-Bold.ttf"

AEGUK_MUSIC_PATH = "./resources/musics/aegukMusic.mp3"

AEGUK_RECORD_PATH = "./resources/aeguk_record.png"
TAKEDOWN_RECORD_PATH = "./resources/takedown_record.png"
VIRUS_RECORD_PATH = "./resources/virus_record.png"

INTRO_BGM_PATH = "./resources/bgms/introSceneBgm.mp3"
SELECT_BGM_PATH = "./resources/bgms/selectSceneBgm.mp3"

AEGUK_NOTE_PATH = "./resources/musics/json.json"

SLIDE_ANIMATION_RECT = (0, (SCREEN_HEIGHT - RECORD_SCALE - 25) / 3.5, SCREEN_WIDTH, RECORD_SCALE + 185)

FRAME_PER_SECOND = 80 # fps

#------------------------------창 설정------------------------------------------#
pygame.init() #초기화
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT)) # 일정한 크기로 창 띄우기
pygame.display.set_caption("리 듬 게 임") # 창 타이틀 설정

#------------------------------기타 변수 정의역-----------------------------------#
clock = pygame.time.Clock()

intro_background = pygame.image.load(INTRO_BACKGROUND_PATH) # 인트로 배경 불러오기

aeguk_record = pygame.image.load(AEGUK_RECORD_PATH) # 애국가 음반 사진 불러오기
aeguk_record = pygame.transform.scale(aeguk_record, (RECORD_SCALE, RECORD_SCALE))
takedown_record = pygame.image.load(TAKEDOWN_RECORD_PATH)
takedown_record = pygame.transform.scale(takedown_record, (RECORD_SCALE, RECORD_SCALE))
virus_record = pygame.image.load(VIRUS_RECORD_PATH)
virus_record = pygame.transform.scale(virus_record, (RECORD_SCALE, RECORD_SCALE))

arrow = pygame.image.load(ARROW_PATH) # 화살표 불러오기
arrow = pygame.transform.scale(arrow, (125, 125))
back = pygame.image.load(BACK_PATH)
back = pygame.transform.scale(back, (back.get_size()[0] / 5, back.get_size()[1] / 5))
back_hovered = back.copy()
back_hovered.fill((50, 50, 50), special_flags = pygame.BLEND_RGB_SUB)
intro_start = pygame.image.load(INTRO_START_PATH) # 인트로 시작 버튼 불러오기
intro_start = pygame.transform.scale(intro_start, (intro_start.get_size()[0] * 1.5, intro_start.get_size()[1] * 1.5))
intro_start_hovered = intro_start.copy() # 인트로 시작 버튼 호버 설정
intro_start_hovered.fill((50, 50, 50), special_flags = pygame.BLEND_RGB_SUB)
play = pygame.image.load(PLAY_PATH)
play = pygame.transform.scale(play, (play.get_size()[0] / 5, play.get_size()[1] / 5))
play_hovered = play.copy()
play_hovered.fill((50, 50, 50), special_flags = pygame.BLEND_RGB_SUB)

select_arrow_r = pygame.image.load(SELECT_ARROW_PATH)
select_arrow_r = pygame.transform.scale(select_arrow_r, (select_arrow_r.get_size()[0] / 5, select_arrow_r.get_size()[1] / 5))
select_arrow_hovered_r = select_arrow_r.copy()
select_arrow_hovered_r.fill((50, 50, 50), special_flags = pygame.BLEND_RGB_SUB)
select_arrow_l = pygame.transform.rotate(select_arrow_r, 180)
select_arrow_hovered_l = pygame.transform.rotate(select_arrow_hovered_r, 180)

galmuriFont = pygame.font.Font(GALMURI_FONT_PATH, 135)

recordPhoto = [aeguk_record, takedown_record, virus_record] # 음반 사진 리스트
recordTitle = ["애국가", "Takedown", "베토벤 바이러스"] # 음반 제목 리스트
music = [AEGUK_MUSIC_PATH] # 음악 리스트

scene = "introScene" # 현재 화면
item = 0 # 선택된 음악의 인덱스
itemCount = len(recordPhoto)

keyFirst = ''
#---------------------------클래스 정의역-------------------------------------#
class Button: # 버튼 클래스 정의
    def __init__(self, img, img_hovered, x, y, action):
        self.x = x
        self.y = y
        self.rect = img.get_rect(topleft = (self.x, self.y))
        self.action = action
        self.img = img
        self.img_hovered = img_hovered
        
    def draw(self):
        mouse = pygame.mouse.get_pos() # 마우스 위치 겟

        if self.rect.collidepoint(mouse): # 버튼 호버 처리
            screen.blit(self.img_hovered, (self.x, self.y))
        else:
            screen.blit(self.img, (self.x, self.y))    

    def clicked(self, event): # 좌클릭 처리
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.action()

#---------------------------함수 정의역---------------------------------------#
def coord(s, a): # 글자 중앙 좌표 계산
    r = 0
    for i in range(0, len(s)):
        if s[i] == ' ':
            r += a / 2
        elif ord(s[i]) >= 65 and ord(s[i]) <= 97:
            r -= a / 2
        else:
            r += a
    return (SCREEN_WIDTH - r) / 2

def changeItem(direction):
    global item
    if direction: # 오른 화살표
        if item == itemCount - 1:
            item = 0
        else:
            item += 1
    else: # 왼 화살표
        if item == 0:
            item = itemCount - 1
        else:
            item -= 1

def changeScene(sc): # 화면 전환
    global scene
    scene = sc

def introScene(): # 인트로 화면 처리
    global scene
    screen.blit(intro_background, (0, 0)) # 불러온 배경 화면에 띄우기
    screen.blit(pygame.transform.rotate(arrow, -15), (350, 425))
    screen.blit(pygame.transform.rotate(arrow, 135), (0, 500))

    title = galmuriFont.render("리듬게임", True, (0, 255, 0))
    screen.blit(pygame.font.Font(GALMURI_FONT_PATH, 140).render("리듬게임", True, (0, 100, 0)), (SCREEN_WIDTH * 0.08, SCREEN_HEIGHT * 0.15))
    screen.blit(title, (SCREEN_WIDTH * 0.06, SCREEN_HEIGHT * 0.14))
    
    pygame.mixer.music.load(INTRO_BGM_PATH) # 배경음악 인트로 브금으로 초기화
    pygame.mixer.music.play(-1)

    startButton = Button(intro_start, intro_start_hovered, 155, 570, lambda : changeScene("selectScene")) # (155, 570) 불러온 시작 버튼 띄우기
    while scene == "introScene":
        startButton.draw()
        for event in pygame.event.get():
            if event.type == pygame.QUIT: # 창 닫기 누르면 닫혀라
                return "quit"
            startButton.clicked(event)
        pygame.display.update()
        clock.tick(FRAME_PER_SECOND) # fps 제한 적용
    return scene

def selectScene(): # 선택 화면 처리
    global scene
    global item

    item = 0

    screen.fill((0, 0, 0))
    title = pygame.font.Font(GALMURI_FONT_PATH, 70).render("음악 선택", True, (255, 255, 255))
    screen.blit(title, ((SCREEN_WIDTH - 315) / 2, SCREEN_HEIGHT * 0.015))
    pygame.draw.rect(screen, (255, 255, 255), ((SCREEN_WIDTH - RECORD_SCALE - 25) / 2, (SCREEN_HEIGHT - RECORD_SCALE - 25) / 3.5, RECORD_SCALE + 25, RECORD_SCALE + 25), 0, 15) # 앨범
    screen.blit(recordPhoto[item], ((SCREEN_WIDTH - RECORD_SCALE) / 2, (SCREEN_HEIGHT - RECORD_SCALE + 25) / 3.5))

    playButton = Button(play, play_hovered, (SCREEN_WIDTH - play.get_size()[0]) / 2, RECORD_SCALE + 270, lambda: changeScene("playScene"))
    rightButton = Button(select_arrow_r, select_arrow_hovered_r, SCREEN_WIDTH - select_arrow_r.get_size()[0] - 70, RECORD_SCALE + 150, lambda: changeItem(1))
    leftButton = Button(select_arrow_l, select_arrow_hovered_l, 70, RECORD_SCALE + 150, lambda: changeItem(0))

    backButton = Button(back, back_hovered, 20, 20, lambda: changeScene("introScene"))

    pygame.mixer.music.load(SELECT_BGM_PATH)
    pygame.mixer.music.play(-1)

    while scene == "selectScene":
        screen.fill((0, 0, 0), SLIDE_ANIMATION_RECT)
        playButton.draw()
        rightButton.draw()
        leftButton.draw()
        backButton.draw()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            playButton.clicked(event)
            rightButton.clicked(event)
            leftButton.clicked(event)
            backButton.clicked(event)
        songName = pygame.font.Font(GALMURI_FONT_PATH, 45).render(recordTitle[item], True, (255, 255, 255)) # 곡 이름
        screen.blit(songName, (coord(recordTitle[item], 45), RECORD_SCALE + 160))
        pygame.draw.rect(screen, (255, 255, 255), ((SCREEN_WIDTH - RECORD_SCALE - 25) / 2, (SCREEN_HEIGHT - RECORD_SCALE - 25) / 3.5, RECORD_SCALE + 25, RECORD_SCALE + 25), 0, 15)
        screen.blit(recordPhoto[item], ((SCREEN_WIDTH - RECORD_SCALE) / 2, (SCREEN_HEIGHT - RECORD_SCALE + 25) / 3.5))
        pygame.display.update()
        clock.tick(FRAME_PER_SECOND)
    return scene

def playScene():
    global scene
    global item

    one_pressed = False
    two_pressed = False
    three_pressed = False
    four_pressed = False


    pygame.mixer.music.stop()

    pygame.mixer.music.load(music[item])
    pygame.mixer.music.play()
    while scene == "playScene":
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    one_pressed = True
                elif event.key == pygame.K_s:
                    two_pressed = True
                elif event.key == pygame.K_d:
                    three_pressed = True
                elif event.key == pygame.K_f:
                    four_pressed = True
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    one_pressed = False
                elif event.key == pygame.K_s:
                    two_pressed = False
                elif event.key == pygame.K_d:
                    three_pressed = False
                elif event.key == pygame.K_f:
                    four_pressed = False
        screen.fill((0, 0, 0))
        for i in range(SCREEN_WIDTH // 4, SCREEN_WIDTH, SCREEN_WIDTH // 4):
            pygame.draw.line(screen, (255, 255, 255), (i, 0), (i, SCREEN_HEIGHT - 200))
        for i in range(0, SCREEN_WIDTH, SCREEN_WIDTH // 4): # 키보드 입력 표시선
            pygame.draw.lines(screen, (255, 0, 0), True, [(i, SCREEN_HEIGHT - 200), (i + SCREEN_WIDTH / 4, SCREEN_HEIGHT - 200), (i + SCREEN_WIDTH / 4, SCREEN_HEIGHT - 100), (i, SCREEN_HEIGHT - 100)], 10)
        pygame.draw.line(screen, (0, 255, 0), (0, SCREEN_HEIGHT - 200), (SCREEN_WIDTH, SCREEN_HEIGHT - 200), 10)
        if one_pressed:
            pygame.draw.rect(screen, (255, 255, 255), (10, SCREEN_HEIGHT - 190, SCREEN_WIDTH / 4 - 20, 80))
        if two_pressed:
            pygame.draw.rect(screen, (255, 255, 255), (SCREEN_WIDTH / 4 + 10, SCREEN_HEIGHT - 190, SCREEN_WIDTH / 4 - 20, 80))
        if three_pressed:
            pygame.draw.rect(screen, (255, 255, 255), (SCREEN_WIDTH / 4 * 2 + 10, SCREEN_HEIGHT - 190, SCREEN_WIDTH / 4 - 20, 80))
        if four_pressed:
            pygame.draw.rect(screen, (255, 255, 255), (SCREEN_WIDTH / 4 * 3 + 10, SCREEN_HEIGHT - 190, SCREEN_WIDTH / 4 - 20, 80))
        pygame.display.update()
        clock.tick(FRAME_PER_SECOND)

#--------------------------사실상 메인 코드임----------------------------------#
while True:
    if scene == "introScene":
        scene = introScene()
    elif scene == "selectScene":
        scene = selectScene()
    elif scene == "playScene":
        scene = playScene()
    elif scene == "quit":
        break
    clock.tick(FRAME_PER_SECOND)

pygame.quit()